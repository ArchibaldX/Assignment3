package com.archibald.main;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;


/**
 * @author Archibaldx
 * Database Helper
 */
public class DBHelper2014302580045 {
	private String ip;
	private String user;
	private String pwd;
	private int port;
	private String dbname;
	private String url;

	public Connection conn = null;
	private Statement stmt;

	/**
	 * @param ip
	 * @param port
	 * @param user
	 * @param pwd
	 * @param dbname
	 * Init Databases
	 */
	public DBHelper2014302580045(String ip,int port,String user,String pwd,String dbname) {
		this.ip=ip;
		this.user=user;
		this.pwd=pwd;
		this.port=port;
		this.dbname = dbname;
		this.url = "jdbc:mysql://"+this.ip+":"+
				this.port+"/"+this.dbname+"?"+ 
				"user="+this.user+"&password="+this.pwd+"&"+
				"useUnicode=true&characterEncoding=UTF8";
	}

	/**
	 * @return
	 * Open Connection
	 */
	public void Connect(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(url);
			System.out.println("����MySQL��������ɹ�");
		} catch (Exception e) {
			System.out.println("����MySQL��������ʧ��");
		}
	}

	/**
	 * Close Connection
	 */
	public void closeConn(){
		try {
			conn.close();
		} catch (SQLException e) {
			System.out.println("�ر�����ʱ����");
		}
	}

	/**
	 * @param str
	 * @return The items NUM that updated
	 * Execute SQL statement
	 */
	public synchronized int execUpdateSQL(String str){
		int result;
		try {
			stmt = conn.createStatement();
			result = stmt.executeUpdate(str);
			return result;
		} catch (SQLException e) {
			System.out.println("�����﷨�����ݿ����ӻ���� "+str);
			return -1;
		}
	}

	/**
	 * @param str
	 * @return
	 * Execute SQL statementGet ResultSet
	 */
	public ResultSet execQuerySQL(String str){
		try {
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(str);
			return rs;
		} catch (Exception e) {
			System.out.println("�����﷨�����ݿ����ӻ���� "+str);
			return null;
		}
	}	
}


