package com.archibald.main;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * @author Archibaldx
 * the Crawler
 */
public class Crawler2014302580045 {
	//The first url to parse
	private String url;
	//The number of threads
	private int threadNum;
	//Create a threadpool to execute thread
	private ThreadPoolExecutor executor;
	//Constructor / Init 
	public Crawler2014302580045(String url,int threadNum,int maxDepth) {
		CrawlThread2014302580045.MAX_DEPTH = maxDepth;
		this.url = url;
		this.threadNum = threadNum;
		executor = new ThreadPoolExecutor(this.threadNum, this.threadNum, 3, TimeUnit.SECONDS, new LinkedBlockingQueue<Runnable>());
	}
	
	/**
	 * Start the threads
	 */
	public void start(){
		long startTime = System.currentTimeMillis();
		//Add Main url into queue
		Queue2014302580045.Add(url, 1);
		for(int i=0;i<threadNum;i++){
			//Execute threads
			executor.execute(new CrawlThread2014302580045());
		}
		end(startTime);
	}

	/**
	 * @param startTime
	 * Transications when the parse finished
	 */
	private void end(long startTime){
		while(!(CrawlThread2014302580045.count==threadNum&&Queue2014302580045.Size()==0)){
			System.out.print("");
			try {
				//Make the main thread sleep to save the resource
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		//Get the time
		long useTime = System.currentTimeMillis() - startTime;
		System.out.println("ʹ��ʱ��:"+(double)useTime/1000.0+"s ҳ����:"+Queue2014302580045.count);
		//Stop the Threads
		executor.shutdown();
	}
}

