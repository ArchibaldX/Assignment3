package com.archibald.main;

import java.util.HashMap;
import java.util.LinkedList;

/**
 * @author Archibaldx
 * The queue to control URLS
 */
public class Queue2014302580045 {
	public static int count; 
    private static HashMap<String,Integer> m_appear = new HashMap<String,Integer>();
    private static LinkedList<String> m_queue = new LinkedList<String>();
    
    /**
     * @param url
     * @param depth
     * Add a new URL to queue
     */
    public synchronized static void Add(String url,int depth) {
        if( !m_appear.containsKey(url)) {
        	count++;
            m_appear.put(url, depth);
            m_queue.addLast(url);
        }
    }  
    
    /**
     * @return
     * Get a url from Queue
     */
    public synchronized static String Fetch() {
        if( !m_queue.isEmpty() ) {
            return m_queue.poll();
        }
        return null;
    }
    
    /**
     * @return
     * Get the Size of the queue that waited to be processed
     */
    public static int Size() {
        return m_queue.size();
    }
    
    /**
     * @param url
     * @return
     * Judge whether the url had been processed
     */
    public static boolean contains(String url){
		return m_appear.containsKey(url);
    }
    
    /**
     * @param str
     * @return
     * Get the Depth of the url;
     */
    public synchronized static int getDepth(String str){
    	return m_appear.get(str);
    } 
}
