package com.archibald.main;




/**
 * @author Archibaldx
 *	The CrawlThread to parse doc
 */
public class CrawlThread2014302580045 implements Runnable{
	//Create DBHelper
	public static DBHelper2014302580045 db = new DBHelper2014302580045("localhost", 13306,"root", "123456", "teacherinfo");
	
	//The signal to Synchronize threads
	public static Object signal = new Object();
	
	//The counts of waited threads
	public static int count = 0;
	
	//MAX_DEPTH
	public static int MAX_DEPTH = 0;
	
	//The object to ProcessDoc 
	private ProcessDoc2014302580045 pd = new ProcessDoc2014302580045();
	
	@Override
	public void run() {
		while (true) {
			//Constantly Fetch the queue
			String tmp = Queue2014302580045.Fetch();  
			if(tmp!=null){
				//Start crawl
				crawl(tmp);  
			}else{  
				//Synchronize the thread
				synchronized(CrawlThread2014302580045.signal) {  
					try {  
						CrawlThread2014302580045.count++;
						CrawlThread2014302580045.signal.wait();  
					} catch (InterruptedException e) {
						System.out.println("�߳�ͬ��");
					}  
				}  
			}  
		} 
	}
	//Crawl function
	private void crawl(String sUrl){ 
		int depth = Queue2014302580045.getDepth(sUrl); 
		//If the depth is less than MAX_DEPTH,then start parsing
		if(depth <= MAX_DEPTH){ 
			pd.parse(sUrl,depth+1);
		}  
	}
}











